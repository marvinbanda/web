<?php
// Database connection
include 'db.php';

// Function to get all tables
function getTables($conn) {
    $tables = [];
    $result = $conn->query("SHOW TABLES");
    if ($result) {
        while ($row = $result->fetch_array()) {
            $tables[] = $row[0];
        }
    } else {
        echo "Error fetching tables: " . $conn->error;
    }
    return $tables;
}

// Function to get records from a table
function getRecords($conn, $table) {
    $records = [];
    $result = $conn->query("SELECT * FROM $table");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $records[] = $row;
        }
    } else {
        echo "Error fetching records from $table: " . $conn->error;
    }
    return $records;
}

// Function to calculate totals
function calculateTotals($conn, $tables) {
    $totals = [];
    foreach ($tables as $table) {
        $result = $conn->query("SELECT SUM(deposit) AS total_deposit, SUM(withdraw) AS total_withdraw FROM $table");
        if ($result) {
            $row = $result->fetch_assoc();
            $totals[$table] = [
                'deposit' => $row['total_deposit'] ?? 0,
                'withdraw' => $row['total_withdraw'] ?? 0,
                'balance' => ($row['total_deposit'] ?? 0) - ($row['total_withdraw'] ?? 0)
            ];
        } else {
            echo "Error calculating totals for $table: " . $conn->error;
        }
    }
    return $totals;
}

// Function to get metadata
function getMetadata($conn, $tables) {
    $metadata = [];
    foreach ($tables as $table) {
        $result = $conn->query("SELECT phone_number, date_created FROM table_metadata WHERE table_name = '$table'");
        if ($result) {
            if ($row = $result->fetch_assoc()) {
                $metadata[$table] = $row;
            } else {
                $metadata[$table] = ['phone_number' => 'N/A', 'date_created' => 'N/A'];
            }
        } else {
            echo "Error fetching metadata for $table: " . $conn->error;
        }
    }
    return $metadata;
}

// Fetching data
$tables = getTables($conn);
$metadata = getMetadata($conn, $tables);
$totals = calculateTotals($conn, $tables);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['create_table'])) {
        $new_table = $_POST['table_name'];
        $phone_number = $_POST['phone_number'];
        $conn->query("CREATE TABLE $new_table (id INT AUTO_INCREMENT PRIMARY KEY, date DATE, deposit DECIMAL(10,2), withdraw DECIMAL(10,2))");
        $conn->query("INSERT INTO table_metadata (table_name, phone_number, date_created) VALUES ('$new_table', '$phone_number', NOW())");
    } elseif (isset($_POST['delete_table'])) {
        $table_name = $_POST['table_name'];
        $conn->query("DROP TABLE $table_name");
        $conn->query("DELETE FROM table_metadata WHERE table_name = '$table_name'");
    } elseif (isset($_POST['insert_record'])) {
        $table_name = $_POST['table_name'];
        $date = $_POST['date'];
        $deposit = $_POST['deposit'];
        $withdraw = $_POST['withdraw'];
        $conn->query("INSERT INTO $table_name (date, deposit, withdraw) VALUES ('$date', '$deposit', '$withdraw')");
    } elseif (isset($_POST['update_record'])) {
        $table_name = $_POST['table_name'];
        $record_id = $_POST['record_id'];
        $date = $_POST['date'];
        $deposit = $_POST['deposit'];
        $withdraw = $_POST['withdraw'];
        $conn->query("UPDATE $table_name SET date='$date', deposit='$deposit', withdraw='$withdraw' WHERE id='$record_id'");
    } elseif (isset($_POST['delete_record'])) {
        $table_name = $_POST['table_name'];
        $record_id = $_POST['record_id'];
        $conn->query("DELETE FROM $table_name WHERE id='$record_id'");
    } elseif (isset($_POST['read_table'])) {
        $table_name = $_POST['table_name'];
        $records = getRecords($conn, $table_name);
        $chartDates = array_column($records, 'date');
        $chartDeposits = array_column($records, 'deposit');
        $chartWithdraws = array_column($records, 'withdraw');
    }
    // Refreshing data
    $tables = getTables($conn);
    $metadata = getMetadata($conn, $tables);
    $totals = calculateTotals($conn, $tables);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Financial Management</title>
    <style>
        .popup {
            display: none;
            position: fixed;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            border: 1px solid #ccc;
            padding: 20px;
            background: #fff;
        }
        .popup.show {
            display: block;
        }
        .close-button {
            cursor: pointer;
            margin-top: 10px;
        }
    </style>
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
    <script>
        function showCreateTablePopup() {
            document.getElementById('create-table-popup').classList.add('show');
        }
        function closeCreateTablePopup() {
            document.getElementById('create-table-popup').classList.remove('show');
        }
        function showUpdateRecordPopup(table, id, date, deposit, withdraw) {
            document.getElementById('update-record-popup').classList.add('show');
            document.getElementById('update_table_name').value = table;
            document.getElementById('update_record_id').value = id;
            document.getElementById('update_date').value = date;
            document.getElementById('update_deposit').value = deposit;
            document.getElementById('update_withdraw').value = withdraw;
        }
        function closeUpdateRecordPopup() {
            document.getElementById('update-record-popup').classList.remove('show');
        }
    </script>
</head>
<body>

<h1>Financial Management</h1>

<!-- Create New Table Form -->
<button onclick="showCreateTablePopup()">Create New Table</button>
<div id="create-table-popup" class="popup">
    <form method="POST">
        <h2>Create New Table</h2>
        <label for="table_name">Table Name:</label>
        <input type="text" name="table_name" required>
        <label for="phone_number">Phone Number:</label>
        <input type="text" name="phone_number" required>
        <input type="submit" name="create_table" value="Create Table">
    </form>
    <button class="close-button" onclick="closeCreateTablePopup()">Close</button>
</div>

<h2>Tables</h2>
<table border="1">
    <thead>
        <tr>
            <th>Table Name</th>
            <th>Phone Number</th>
            <th>Date Created</th>
            <th>Total Deposit</th>
            <th>Total Withdraw</th>
            <th>Balance</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($totals as $table_name => $data): ?>
            <tr>
                <td><?= $table_name ?></td>
                <td><?= isset($metadata[$table_name]['phone_number']) ? $metadata[$table_name]['phone_number'] : 'N/A' ?></td>
                <td><?= isset($metadata[$table_name]['date_created']) ? $metadata[$table_name]['date_created'] : 'N/A' ?></td>
                <td><?= $data['deposit'] ?></td>
                <td><?= $data['withdraw'] ?></td>
                <td><?= $data['balance'] ?></td>
                <td>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="table_name" value="<?= $table_name ?>">
                        <input type="submit" name="read_table" value="View Records">
                    </form>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="table_name" value="<?= $table_name ?>">
                        <input type="submit" name="delete_table" value="Delete Table">
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<h3>Grand Totals</h3>
<p>Total Deposit: <?= array_sum(array_column($totals, 'deposit')) ?></p>
<p>Total Withdraw: <?= array_sum(array_column($totals, 'withdraw')) ?></p>
<p>Balance: <?= array_sum(array_column($totals, 'balance')) ?></p>

<?php if (isset($records)): ?>
    <h2>Records for <?= $table_name ?></h2>
    <table border="1">
        <thead>
            <tr>
                <th>Date</th>
                <th>Deposit</th>
                <th>Withdraw</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($records as $record): ?>
                <tr>
                    <td><?= $record['date'] ?></td>
                    <td><?= $record['deposit'] ?></td>
                    <td><?= $record['withdraw'] ?></td>
                    <td>
                        <button onclick="showUpdateRecordPopup('<?= $table_name ?>', '<?= $record['id'] ?>', '<?= $record['date'] ?>', '<?= $record['deposit'] ?>', '<?= $record['withdraw'] ?>')">Edit</button>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="table_name" value="<?= $table_name ?>">
                            <input type="hidden" name="record_id" value="<?= $record['id'] ?>">
                            <input type="submit" name="delete_record" value="Delete">
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <h3>Totals for <?= $table_name ?></h3>
    <p>Total Deposit: <?= $totals[$table_name]['deposit'] ?></p>
    <p>Total Withdraw: <?= $totals[$table_name]['withdraw'] ?></p>
    <p>Balance: <?= $totals[$table_name]['balance'] ?></p>
    <button onclick="showInsertRecordPopup()">Insert New Record</button>
    <div id="insert-record-popup" class="popup">
        <form method="POST">
            <h2>Insert New Record</h2>
            <input type="hidden" name="table_name" value="<?= $table_name ?>">
            <label for="date">Date:</label>
            <input type="date" name="date" required>
            <label for="deposit">Deposit:</label>
            <input type="number" step="0.01" name="deposit">
            <label for="withdraw">Withdraw:</label>
            <input type="number" step="0.01" name="withdraw">
            <input type="submit" name="insert_record" value="Insert Record">
        </form>
        <button class="close-button" onclick="closeInsertRecordPopup()">Close</button>
    </div>

    <!-- Plotly Chart -->
    <div id="chart"></div>
    <script>
        var chartDates = <?= json_encode($chartDates) ?>;
        var chartDeposits = <?= json_encode($chartDeposits) ?>;
        var chartWithdraws = <?= json_encode($chartWithdraws) ?>;

        var trace1 = {
            x: chartDates,
            y: chartDeposits,
            type: 'scatter',
            mode: 'lines+markers',
            name: 'Deposits',
            line: {shape: 'linear', color: 'green'}
        };

        var trace2 = {
            x: chartDates,
            y: chartWithdraws,
            type: 'scatter',
            mode: 'lines+markers',
            name: 'Withdrawals',
            line: {shape: 'linear', color: 'red'}
        };

        var layout = {
            title: 'Deposits and Withdrawals over Time',
            xaxis: {title: 'Date'},
            yaxis: {title: 'Amount'},
        };

        var data = [trace1, trace2];

        Plotly.newPlot('chart', data, layout);
    </script>
<?php endif; ?>

<div id="update-record-popup" class="popup">
    <form method="POST">
        <h2>Update Record</h2>
        <input type="hidden" name="table_name" id="update_table_name">
        <input type="hidden" name="record_id" id="update_record_id">
        <label for="date">Date:</label>
        <input type="date" name="date" id="update_date" required>
        <label for="deposit">Deposit:</label>
        <input type="number" step="0.01" name="deposit" id="update_deposit">
        <label for="withdraw">Withdraw:</label>
        <input type="number" step="0.01" name="withdraw" id="update_withdraw">
        <input type="submit" name="update_record" value="Update Record">
    </form>
    <button class="close-button" onclick="closeUpdateRecordPopup()">Close</button>
</div>

<script>
    function showInsertRecordPopup() {
        document.getElementById('insert-record-popup').classList.add('show');
    }
    function closeInsertRecordPopup() {
        document.getElementById('insert-record-popup').classList.remove('show');
    }
</script>

</body>
</html>
